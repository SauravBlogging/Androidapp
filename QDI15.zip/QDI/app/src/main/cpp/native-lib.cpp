#include <jni.h>
#include <dlfcn.h>

// Client function structure
typedef double (*qdi_kernel_t)(double, double, double, double, double, double, double, double);

extern "C" JNIEXPORT jdouble JNICALL
Java_com_example_weathersnap_MainActivity_executeQdi(JNIEnv* env, jobject thiz, 
    jdouble t, jdouble x, jdouble y, jdouble z, jdouble vx, jdouble vy, jdouble vz, jdouble dt) {
    
    // 1. Load the actual libqdim.so
    void* handle = dlopen("libqdim.so", RTLD_NOW);
    if (!handle) {
        return -1.0; 
    }

    // 2. Locate the qdi_kernel function
    qdi_kernel_t qdi_kernel = (qdi_kernel_t)dlsym(handle, "qdi_kernel");
    if (!qdi_kernel) {
        dlclose(handle);
        return -2.0; 
    }

    // 3. Calculate using inputs from Kotlin
    double result = qdi_kernel(t, x, y, z, vx, vy, vz, dt);

    // 4. Clean memory and return result
    dlclose(handle);
    return result;
}
