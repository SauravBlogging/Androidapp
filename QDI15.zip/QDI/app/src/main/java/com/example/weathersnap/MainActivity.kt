package com.example.weathersnap

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QdiTestScreen(this)
        }
    }

    // External function with 8 inputs
    external fun executeQdi(
        t: Double, x: Double, y: Double, z: Double,
        vx: Double, vy: Double, vz: Double, dt: Double
    ): Double

    companion object {
        init {
            System.loadLibrary("weathersnap")
        }
    }
}

@Composable
fun QdiTestScreen(mainActivity: MainActivity) {
    var outputResult by remember { mutableStateOf("Tap the test button below") }
    var dtInput by remember { mutableStateOf("1.0") }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFE3F2FD)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            
            // Centered content
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // QDI Logo Centered & Dark
                Image(
                    painter = painterResource(id = R.drawable.qdi_logo),
                    contentDescription = "QDI Logo",
                    colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(Color.DarkGray),
                    modifier = Modifier
                        .padding(bottom = 32.dp)
                        .size(100.dp)
                )
                OutlinedTextField(
                    value = dtInput,
                    onValueChange = { dtInput = it },
                    label = { Text("Enter dt (seconds)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Button(
                    onClick = {
                        val dtValue = dtInput.toDoubleOrNull() ?: 1.0
                        val res = mainActivity.executeQdi(1000.0, 6.0, 0.0, 1000.0, 3.0, 400.0, 0.0, dtValue)
                        val formattedRes = String.format(java.util.Locale.US, "%.6f", res)
                        outputResult = "Drift (dt = ${dtValue}s): $formattedRes"
                    }
                ) {
                    Text("Run Test")
                }

                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    border = BorderStroke(1.dp, Color.LightGray),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = outputResult,
                        modifier = Modifier.padding(16.dp),
                        fontSize = 16.sp
                    )
                }
            } // closes Column
        } // closes Box
    } // closes Surface
} // closes function