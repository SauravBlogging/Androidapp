package com.example.weathersnap

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QdiMainAppScreen(this)
        }
    }

    external fun executeQdi(
        t: Double, x: Double, y: Double, z: Double,
        vx: Double, vy: Double, vz: Double, dt: Double
    ): Double

    companion object {
        init {
            System.loadLibrary("weathersnap")
        }
    }
}

@Composable
fun QdiMainAppScreen(mainActivity: MainActivity) {
    // Inputs
    var x by remember { mutableStateOf("6.0") }
    var y by remember { mutableStateOf("0.0") }
    var z by remember { mutableStateOf("1000.0") }
    var vx by remember { mutableStateOf("3.0") }
    var vy by remember { mutableStateOf("400.0") }
    var vz by remember { mutableStateOf("0.0") }
    var dt by remember { mutableStateOf("1.0") }

    // Sensor State
    var isSensorOn by remember { mutableStateOf(false) }
    var telemetrySource by remember { mutableStateOf(TelemetrySource.PHONE_IMU) }
    val context = LocalContext.current
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }

    // Outputs
    var accumD by remember { mutableStateOf(0.0) }
    var localTime by remember { mutableStateOf(0.0) }
    var trueTime by remember { mutableStateOf(1000.0) } // Initial t = 1000.0
    var instantDrift by remember { mutableStateOf(0.0) }

    // Graph Data
    var graphPoints by remember { mutableStateOf(listOf<GraphDataPoint>()) }

    // State
    var isRunning by remember { mutableStateOf(false) }
    var isExpired by remember { mutableStateOf(false) }

    // Lifecycle aware sensor registration
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, isSensorOn, telemetrySource) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (telemetrySource == TelemetrySource.PHONE_IMU) {
                    when (event.sensor.type) {
                        Sensor.TYPE_ACCELEROMETER -> {
                            x = String.format(Locale.US, "%.3f", event.values[0])
                            y = String.format(Locale.US, "%.3f", event.values[1])
                            z = String.format(Locale.US, "%.3f", event.values[2])
                        }
                        Sensor.TYPE_GYROSCOPE -> {
                            vx = String.format(Locale.US, "%.3f", event.values[0])
                            vy = String.format(Locale.US, "%.3f", event.values[1])
                            vz = String.format(Locale.US, "%.3f", event.values[2])
                        }
                    }
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        
        val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && isSensorOn) {
                accelerometer?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
                gyroscope?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
            } else if (event == Lifecycle.Event.ON_PAUSE) {
                sensorManager.unregisterListener(listener)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        // Handle initial registration when effect launches
        if (isSensorOn && lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            accelerometer?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
            gyroscope?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
        }

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            sensorManager.unregisterListener(listener)
        }
    }


    // Continuous Loop
    LaunchedEffect(isRunning) {
        while (isRunning && isActive) {
            val dtVal = dt.toDoubleOrNull() ?: 1.0
            val cX = x.toDoubleOrNull() ?: 0.0
            val cY = y.toDoubleOrNull() ?: 0.0
            val cZ = z.toDoubleOrNull() ?: 0.0
            val cVx = vx.toDoubleOrNull() ?: 0.0
            val cVy = vy.toDoubleOrNull() ?: 0.0
            val cVz = vz.toDoubleOrNull() ?: 0.0

            val currentT = 1000.0 + localTime
            val drift = mainActivity.executeQdi(currentT, cX, cY, cZ, cVx, cVy, cVz, dtVal)
            
            if (drift.isNaN() || drift == -999.0 || drift <= -100.0) {
                isExpired = true
                isRunning = false
                break
            }
            
            instantDrift = drift
            accumD += drift
            localTime += dtVal
            trueTime = currentT + accumD

            val newPoint = GraphDataPoint(instantDrift, accumD, localTime.toFloat())
            graphPoints = (graphPoints + newPoint).takeLast(100) // Keep last 100 points

            // Loop delay based on dt (max 1 second for UI responsiveness)
            val delayMs = (dtVal * 1000).toLong().coerceIn(100L, 1000L)
            delay(delayMs)
        }
    }

    // Transparent Dashboard Background
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isExpired) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x33FF5252)),
                    border = BorderStroke(1.dp, Color(0xFFFF5252)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚠️", fontSize = 28.sp)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("VERSION EXPIRED", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("The native algorithm has expired.", color = Color(0xFFFFCCBC), fontSize = 12.sp)
                        }
                    }
                }
            }

            // High-Contrast Glowing Logo (Interactive Toggle)
            val logoGlow by animateColorAsState(if (isRunning) Color(0xFF00E676) else Color.Cyan)
            val logoElevation by animateDpAsState(if (isRunning) 60.dp else 20.dp)

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .padding(bottom = 16.dp)
                    .size(110.dp)
                    .shadow(elevation = logoElevation, shape = androidx.compose.foundation.shape.CircleShape, ambientColor = logoGlow, spotColor = logoGlow)
                    .background(Color.Transparent, shape = androidx.compose.foundation.shape.CircleShape)
                    .clickable { isRunning = !isRunning }
            ) {
                Image(
                    painter = painterResource(id = R.drawable.qdi_logo),
                    contentDescription = "QDI Logo Toggle",
                    modifier = Modifier.padding(14.dp).size(82.dp)
                )
            }

            Text("QDI Dashboard", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(24.dp))

            // High-Precision Chronometer
            QdimChronometerCard(
                localTime = localTime,
                trueTime = trueTime,
                accumD = accumD,
                dt = dt.toDoubleOrNull() ?: 1.0,
                isEngineRunning = isRunning
            )
            
            Spacer(modifier = Modifier.height(24.dp))

            // Drift Graph Card (At the top as requested)
            QdimDriftGraphCard(
                graphPoints = graphPoints,
                isEngineRunning = isRunning
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Live Sensor Card UI
            QdimLiveSensorCard(
                telemetry = RawTelemetry(x, y, z, vx, vy, vz, dt),
                activeSensorName = "IMU",
                isSensorOn = isSensorOn,
                telemetrySource = telemetrySource,
                onSelectSource = { source -> telemetrySource = source },
                onToggleSensor = { isSensorOn = !isSensorOn },
                onInputChange = { key, value ->
                    when (key) {
                        "x" -> x = value; "y" -> y = value; "z" -> z = value
                        "vx" -> vx = value; "vy" -> vy = value; "vz" -> vz = value
                        "dt" -> dt = value
                    }
                },
                onRunCustom = { isRunning = true },
                onZeroOrigin = { 
                    accumD = 0.0; localTime = 0.0; trueTime = 1000.0; graphPoints = emptyList()
                },
                onClearInputs = {
                    x = "0.0"; y = "0.0"; z = "0.0"
                    vx = "0.0"; vy = "0.0"; vz = "0.0"
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Original Intact Telemetry Parameters
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0x22FFFFFF)), // Transparent Glass
                border = BorderStroke(1.dp, Color(0x44FFFFFF)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Live Telemetry Status", fontWeight = FontWeight.Bold, color = Color.Cyan)
                    Spacer(Modifier.height(12.dp))
                    Text("Instant Drift: ${String.format(Locale.US, "%.6f", instantDrift)}", color = Color.White, fontSize = 14.sp)
                    Text("Accumulated (accumD): ${String.format(Locale.US, "%.6f", accumD)}", color = Color.White, fontSize = 14.sp)
                    Text("Local Time: ${String.format(Locale.US, "%.1f", localTime)}s", color = Color.White, fontSize = 14.sp)
                    Text("True Time: ${String.format(Locale.US, "%.6f", trueTime)}", color = Color.White, fontSize = 14.sp)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = { mainActivity.finish() },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
                ) {
                    Text("Exit", color = Color.White, fontWeight = FontWeight.Medium)
                }

                Button(
                    onClick = {
                        ReportGenerator.generateAndPrintReport(
                            context = mainActivity, accumD = accumD, localTime = localTime, trueTime = trueTime, dt = dt.toDoubleOrNull() ?: 1.0
                        )
                    },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222222))
                ) {
                    Text("Save", color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}