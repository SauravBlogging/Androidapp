package com.example.weathersnap

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

enum class TelemetrySource { GNSS_RAW, PHONE_IMU }

data class LiveGnssState(
    val hasHardwareFix: Boolean = false,
    val satellitesCount: Int = 0,
    val gpsCount: Int = 0,
    val galileoCount: Int = 0,
    val glonassCount: Int = 0,
    val beidouCount: Int = 0,
    val carrierPhaseLockedCount: Int = 0,
    val clockDriftNsPerSec: Double = 0.0,
    val avgCn0DbHz: Double = 0.0
)

data class RawTelemetry(
    val x: String = "0.0",
    val y: String = "0.0",
    val z: String = "0.0",
    val vx: String = "0.0",
    val vy: String = "0.0",
    val vz: String = "0.0",
    val dt: String = "1.0"
)

data class GraphDataPoint(
    val instantDrift: Double,
    val accumulatedDrift: Double,
    val timeSeconds: Float
)

@Composable
fun QdimLiveSensorCard(
    telemetry: RawTelemetry,
    activeSensorName: String,
    isSensorOn: Boolean = true,
    telemetrySource: TelemetrySource = TelemetrySource.GNSS_RAW,
    gnssState: LiveGnssState = LiveGnssState(),
    onSelectSource: (TelemetrySource) -> Unit = {},
    onToggleSensor: () -> Unit = {},
    onInputChange: (key: String, value: String) -> Unit = { _, _ -> },
    onRunCustom: () -> Unit = {},
    onZeroOrigin: () -> Unit = {},
    onClearInputs: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111111)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header with title & ON/OFF toggle switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val indicatorColor by animateColorAsState(if (isSensorOn) Color(0xFF00E676) else Color(0xFFFF5252))
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(indicatorColor)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (telemetrySource == TelemetrySource.GNSS_RAW) "LIVE GNSS" else "LIVE IMU",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif
                    )
                }

                // Smooth Animated Interactive Switch
                val switchOffset by animateDpAsState(if (isSensorOn) 24.dp else 0.dp)
                val trackColor by animateColorAsState(if (isSensorOn) Color(0xFF00E676) else Color(0xFF333333))
                
                Box(
                    modifier = Modifier
                        .width(52.dp)
                        .height(28.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(trackColor)
                        .clickable { onToggleSensor() }
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .offset(x = switchOffset)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }
            }

            // Minimal Source Selector Switch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF222222), RoundedCornerShape(14.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val isGnss = telemetrySource == TelemetrySource.GNSS_RAW
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isGnss) Color.White else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectSource(TelemetrySource.GNSS_RAW) }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "GNSS",
                            color = if (isGnss) Color.Black else Color(0xFF888888),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                }

                val isImu = telemetrySource == TelemetrySource.PHONE_IMU
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isImu) Color.White else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectSource(TelemetrySource.PHONE_IMU) }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "IMU",
                            color = if (isImu) Color.Black else Color(0xFF888888),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                }
            }

            HorizontalDivider(color = Color(0xFF222222), thickness = 1.dp)

            // Vector 1: Position
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Position (m)",
                    color = Color(0xFF888888),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isSensorOn) {
                        SensorReadoutBox(label = "X", value = telemetry.x, modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Y", value = telemetry.y, modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Z", value = telemetry.z, modifier = Modifier.weight(1f))
                    } else {
                        EditableSensorField(label = "X", value = telemetry.x, onValueChange = { onInputChange("x", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Y", value = telemetry.y, onValueChange = { onInputChange("y", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Z", value = telemetry.z, onValueChange = { onInputChange("z", it) }, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Vector 2: Velocity
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Velocity (m/s)",
                    color = Color(0xFF888888),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isSensorOn) {
                        SensorReadoutBox(label = "Vx", value = telemetry.vx, modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Vy", value = telemetry.vy, modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Vz", value = telemetry.vz, modifier = Modifier.weight(1f))
                    } else {
                        EditableSensorField(label = "Vx", value = telemetry.vx, onValueChange = { onInputChange("vx", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Vy", value = telemetry.vy, onValueChange = { onInputChange("vy", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Vz", value = telemetry.vz, onValueChange = { onInputChange("vz", it) }, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Time Delta
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Interval (s)",
                    color = Color(0xFF888888),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium
                )
                if (isSensorOn) {
                    SensorReadoutBox(label = "Δt", value = telemetry.dt, modifier = Modifier.fillMaxWidth())
                } else {
                    EditableSensorField(label = "Δt", value = telemetry.dt, onValueChange = { onInputChange("dt", it) }, modifier = Modifier.fillMaxWidth())
                }
            }

            // Action Footer
            if (isSensorOn) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF222222),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onZeroOrigin() }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("Zero Origin", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onClearInputs,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF444444)),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Text("Clear", fontSize = 13.sp)
                    }

                    Button(
                        onClick = onRunCustom,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        modifier = Modifier.weight(2f).height(48.dp)
                    ) {
                        Text("Run", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
fun SensorReadoutBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF222222),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = label,
                fontSize = 10.sp,
                color = Color(0xFF888888),
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.SansSerif
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = value.ifBlank { "0.0" },
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                fontFamily = FontFamily.SansSerif,
                maxLines = 1
            )
        }
    }
}

@Composable
fun EditableSensorField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFF888888),
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.SansSerif,
            modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = { onValueChange(it) },
            singleLine = true,
            placeholder = { Text("0.0", color = Color(0xFF444444), fontSize = 14.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            textStyle = TextStyle(
                color = Color.White,
                fontSize = 14.sp,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Start
            ),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF222222),
                unfocusedContainerColor = Color(0xFF222222),
                focusedBorderColor = Color.White,
                unfocusedBorderColor = Color.Transparent,
                cursorColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun QdimDriftGraphCard(
    graphPoints: List<GraphDataPoint>,
    isEngineRunning: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111111)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {

            // Minimal Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE TELEMETRY",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontFamily = FontFamily.SansSerif
                )

                if (isEngineRunning) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Canvas Graph area
            val visiblePoints = graphPoints.takeLast(60)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF181818))
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 0.dp, vertical = 12.dp)
                ) {
                    val w = size.width
                    val h = size.height

                    if (visiblePoints.size < 2) return@Canvas

                    // Path for Error Time (Accumulated Drift)
                    val errorPath = androidx.compose.ui.graphics.Path()
                    val minError = visiblePoints.minOf { it.accumulatedDrift }
                    val maxError = visiblePoints.maxOf { it.accumulatedDrift }
                    val rangeError = (maxError - minError).coerceAtLeast(0.000001)
                    val pErrMin = minError - rangeError * 0.1
                    val pErrMax = maxError + rangeError * 0.1
                    val pErrRange = pErrMax - pErrMin

                    // Path for Corrected Time
                    val correctedPath = androidx.compose.ui.graphics.Path()
                    val minCorr = visiblePoints.minOf { 1000.0 + it.timeSeconds + it.accumulatedDrift }
                    val maxCorr = visiblePoints.maxOf { 1000.0 + it.timeSeconds + it.accumulatedDrift }
                    val rangeCorr = (maxCorr - minCorr).coerceAtLeast(0.000001)
                    val pCorrMin = minCorr - rangeCorr * 0.1
                    val pCorrMax = maxCorr + rangeCorr * 0.1
                    val pCorrRange = pCorrMax - pCorrMin

                    val stepX = w / (visiblePoints.size - 1).coerceAtLeast(1).toFloat()

                    visiblePoints.forEachIndexed { i, pt ->
                        val x = i * stepX
                        
                        val errY = h - (h * ((pt.accumulatedDrift - pErrMin) / pErrRange).toFloat()).coerceIn(0f, h)
                        val corrY = h - (h * ((1000.0 + pt.timeSeconds + pt.accumulatedDrift - pCorrMin) / pCorrRange).toFloat()).coerceIn(0f, h)
                        
                        if (i == 0) {
                            errorPath.moveTo(x, errY)
                            correctedPath.moveTo(x, corrY)
                        } else {
                            errorPath.lineTo(x, errY)
                            correctedPath.lineTo(x, corrY)
                        }
                    }

                    // Draw Error Line
                    drawPath(
                        path = errorPath,
                        color = Color(0xFFFF5252),
                        style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )

                    // Draw Corrected Time Line
                    drawPath(
                        path = correctedPath,
                        color = Color.Cyan,
                        style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
                
                // Legend
                Row(
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).background(Color(0xFFFF5252), CircleShape))
                        Spacer(Modifier.width(4.dp))
                        Text("Error Time", color = Color.White, fontSize = 10.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).background(Color.Cyan, CircleShape))
                        Spacer(Modifier.width(4.dp))
                        Text("Corrected Time", color = Color.White, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QdimChronometerCard(
    localTime: Double,
    trueTime: Double,
    accumD: Double,
    dt: Double,
    isEngineRunning: Boolean,
    modifier: Modifier = Modifier
) {
    val durationMs = (dt * 1000.0).toInt().coerceAtLeast(100)
    
    val animatedLocalTime by animateFloatAsState(
        targetValue = localTime.toFloat(),
        animationSpec = tween(durationMillis = durationMs, easing = LinearEasing)
    )
    
    val animatedTrueTime by animateFloatAsState(
        targetValue = trueTime.toFloat(),
        animationSpec = tween(durationMillis = durationMs, easing = LinearEasing)
    )

    val animatedAccumD by animateFloatAsState(
        targetValue = accumD.toFloat(),
        animationSpec = tween(durationMillis = durationMs, easing = LinearEasing)
    )

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x22FFFFFF)),
        border = BorderStroke(1.dp, Color(0x44FFFFFF)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "HIGH-PRECISION CHRONOMETER",
                color = Color.Cyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.SansSerif
            )
            Spacer(Modifier.height(24.dp))

            Box(
                modifier = Modifier
                    .size(240.dp)
                    .shadow(if (isEngineRunning) 20.dp else 0.dp, CircleShape, ambientColor = Color.Cyan, spotColor = Color.Blue)
                    .background(Color(0xFF0A0A0A), CircleShape)
                    .border(1.dp, Color(0xFF333333), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                // Watch Face Text (Printed on dial, behind hands)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 44.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TRUE TIME", color = Color.Cyan, fontSize = 8.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium)
                        Text(
                            String.format(Locale.US, "%.5f", animatedTrueTime),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DRIFT (μs)", color = Color(0xFFFF5252), fontSize = 8.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium)
                        Text(
                            String.format(Locale.US, "+%.1f", animatedAccumD * 1000000),
                            color = Color(0xFFFF5252),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val safeWidth = size.width.coerceAtLeast(1f)
                    val safeHeight = size.height.coerceAtLeast(1f)
                    val center = Offset(safeWidth / 2, safeHeight / 2)
                    val radius = (safeWidth / 2f).coerceAtLeast(1f)

                    // Outer Static Ring
                    drawCircle(
                        color = Color(0xFF111111),
                        radius = (radius - 10f).coerceAtLeast(0.1f),
                        style = Stroke(width = 20f)
                    )

                    // Draw Ticks
                    for (i in 0 until 120) {
                        val angle = (i * 3) * (Math.PI / 180f)
                        val isMajor = i % 10 == 0
                        val isMedium = i % 5 == 0
                        val tickLength = if (isMajor) 14f else if (isMedium) 8f else 4f
                        val tickThickness = if (isMajor) 2f else 1f
                        val color = if (isMajor) Color.Cyan else Color(0xFF555555)

                        val tickRadius = (radius - 20f).coerceAtLeast(0.1f)
                        val innerTickRadius = (tickRadius - tickLength).coerceAtLeast(0.1f)

                        val start = Offset(
                            x = center.x + tickRadius * Math.cos(angle).toFloat(),
                            y = center.y + tickRadius * Math.sin(angle).toFloat()
                        )
                        val end = Offset(
                            x = center.x + innerTickRadius * Math.cos(angle).toFloat(),
                            y = center.y + innerTickRadius * Math.sin(angle).toFloat()
                        )
                        drawLine(color = color, start = start, end = end, strokeWidth = tickThickness)
                    }

                    val safeLocalTime = (animatedLocalTime).let { if (it.isNaN()) 0f else it }
                    val safeAccumD = (animatedAccumD).let { if (it.isNaN()) 0f else it }

                    val secondAngle = (safeLocalTime % 60f) * 6f - 90f
                    val minuteAngle = ((safeLocalTime / 60f) % 60f) * 6f - 90f
                    val hourAngle = ((safeLocalTime / 3600f) % 12f) * 30f - 90f
                    
                    val driftJitter = ((safeAccumD * 1000000f) % 360f)
                    val driftAngle = driftJitter - 90f

                    // Hour Hand
                    val hRad = Math.toRadians(hourAngle.toDouble())
                    drawLine(
                        color = Color.White,
                        start = center,
                        end = Offset(
                            x = center.x + (radius * 0.5f) * Math.cos(hRad).toFloat(),
                            y = center.y + (radius * 0.5f) * Math.sin(hRad).toFloat()
                        ),
                        strokeWidth = 10f,
                        cap = StrokeCap.Round
                    )

                    // Minute Hand
                    val mRad = Math.toRadians(minuteAngle.toDouble())
                    drawLine(
                        color = Color(0xFFCCCCCC),
                        start = center,
                        end = Offset(
                            x = center.x + (radius * 0.7f) * Math.cos(mRad).toFloat(),
                            y = center.y + (radius * 0.7f) * Math.sin(mRad).toFloat()
                        ),
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )

                    // Second Hand
                    val sRad = Math.toRadians(secondAngle.toDouble())
                    drawLine(
                        color = Color.Cyan,
                        start = center,
                        end = Offset(
                            x = center.x + (radius * 0.85f) * Math.cos(sRad).toFloat(),
                            y = center.y + (radius * 0.85f) * Math.sin(sRad).toFloat()
                        ),
                        strokeWidth = 3f,
                        cap = StrokeCap.Round
                    )

                    // Drift Sweeper Hand (Microsecond Jitter)
                    val dRad = Math.toRadians(driftAngle.toDouble())
                    drawLine(
                        color = Color(0xFFFF5252),
                        start = center,
                        end = Offset(
                            x = center.x + (radius * 0.95f) * Math.cos(dRad).toFloat(),
                            y = center.y + (radius * 0.95f) * Math.sin(dRad).toFloat()
                        ),
                        strokeWidth = 2f,
                        cap = StrokeCap.Round
                    )

                    // Center Pin
                    drawCircle(color = Color.White, radius = 6f, center = center)
                    drawCircle(color = Color(0xFFFF5252), radius = 2f, center = center)
                }
            }
        }
    }
}
