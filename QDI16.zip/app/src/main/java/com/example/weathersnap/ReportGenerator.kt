package com.example.weathersnap

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import java.io.FileOutputStream
import java.io.IOException

object ReportGenerator {

    fun generateAndPrintReport(
        context: Context,
        accumD: Double,
        localTime: Double,
        trueTime: Double,
        dt: Double
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val jobName = "QDI_Drift_Report"

        printManager.print(jobName, object : PrintDocumentAdapter() {
            private var pdfDocument: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                pdfDocument = PdfDocument()
                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, oldAttributes != newAttributes)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size
                val page = pdfDocument?.startPage(pageInfo)

                page?.canvas?.let { canvas ->
                    drawReportContent(canvas, accumD, localTime, trueTime, dt)
                }
                pdfDocument?.finishPage(page)

                try {
                    pdfDocument?.writeTo(FileOutputStream(destination?.fileDescriptor))
                } catch (e: IOException) {
                    callback?.onWriteFailed(e.toString())
                    return
                } finally {
                    pdfDocument?.close()
                    pdfDocument = null
                }
                callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            }

            private fun drawReportContent(canvas: Canvas, accumD: Double, localTime: Double, trueTime: Double, dt: Double) {
                val paint = Paint().apply {
                    color = Color.BLACK
                    textSize = 24f
                    isAntiAlias = true
                }
                
                var y = 50f
                canvas.drawText("QDI Sensor Drift Report", 50f, y, paint)
                y += 50f
                
                paint.textSize = 16f
                canvas.drawText("Time Step (dt): $dt seconds", 50f, y, paint)
                y += 30f
                canvas.drawText("Local Time (Elapsed): ${String.format(java.util.Locale.US, "%.1f", localTime)} seconds", 50f, y, paint)
                y += 30f
                canvas.drawText("Accumulated Drift (accumD): ${String.format(java.util.Locale.US, "%.6f", accumD)}", 50f, y, paint)
                y += 30f
                canvas.drawText("True Time: ${String.format(java.util.Locale.US, "%.6f", trueTime)}", 50f, y, paint)
                y += 50f
                
                paint.color = Color.GRAY
                paint.textSize = 12f
                canvas.drawText("Report generated automatically from QDI test interface.", 50f, y, paint)
            }
        }, null)
    }
}
