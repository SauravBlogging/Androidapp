# Sensor & Graph UI Implementation Guide

This guide extracts the exact UI components used in the WeatherSnap app for the **Live Sensor Telemetry Card** and the **Drift Graph Card**. You can copy-paste these Jetpack Compose components into your new app to achieve the exact same visual design.

> [!NOTE]
> The design uses a "Digital Wellbeing" minimalist approach with deep dark backgrounds (`0xFF080808`), bright neon green accents (`0xFF00E676`), and `FontFamily.Monospace` for a technical, high-precision look.

---

## 1. QdimLiveSensorCard
This is the card that displays live X, Y, Z vector values, velocity, and GNSS/IMU toggles.

```kotlin
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// Note: You will need to define `RawTelemetry`, `LiveGnssState` and `TelemetrySource` data classes/enums in your new app.

@Composable
fun QdimLiveSensorCard(
    telemetry: RawTelemetry,
    activeSensorName: String,
    isSensorOn: Boolean = true,
    telemetrySource: TelemetrySource = TelemetrySource.GNSS_RAW,
    gnssState: LiveGnssState = LiveGnssState(),
    onSelectSource: (TelemetrySource) -> Unit = {},
    onToggleSensor: () -> Unit = {},
    onInputChange: (key: String, value: String) -> Unit = { _, _ -> },
    onRunCustom: () -> Unit = {},
    onZeroOrigin: () -> Unit = {},
    onClearInputs: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C0C0C)),
        modifier = modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isSensorOn) Color(0xFF1E1E1E) else Color(0xFF332211),
                RoundedCornerShape(20.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header with title & ON/OFF toggle switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isSensorOn) Color(0xFF00E676) else Color(0xFFFF7043))
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (telemetrySource == TelemetrySource.GNSS_RAW) "GNSS RAW TELEMETRY" else "PHONE SENSOR TELEMETRY",
                        color = if (isSensorOn) Color(0xFF00E676) else Color(0xFFFF7043),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = 1.sp
                    )
                }

                // Interactive ON/OFF toggle pill
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSensorOn) Color(0xFF142B1A) else Color(0xFF2B1A14),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSensorOn) Color(0xFF00E676).copy(alpha = 0.5f) else Color(0xFFFF7043).copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onToggleSensor() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isSensorOn) Color(0xFF00E676) else Color(0xFFFF7043))
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (isSensorOn) "SENSOR: ON" else "SENSOR: OFF",
                            color = if (isSensorOn) Color(0xFF00E676) else Color(0xFFFF7043),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // High-Precision Source Selector Switch (GNSS RAW vs PHONE IMU)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF141414), RoundedCornerShape(12.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val isGnss = telemetrySource == TelemetrySource.GNSS_RAW
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isGnss) Color(0xFF00E676) else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSelectSource(TelemetrySource.GNSS_RAW) }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 7.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🛰️ GNSS RAW",
                            color = if (isGnss) Color.Black else Color(0xFF888888),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                val isImu = telemetrySource == TelemetrySource.PHONE_IMU
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isImu) Color(0xFF00E676) else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSelectSource(TelemetrySource.PHONE_IMU) }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 7.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📱 PHONE IMU",
                            color = if (isImu) Color.Black else Color(0xFF888888),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Detailed GNSS Raw Measurements Status Strip
            if (telemetrySource == TelemetrySource.GNSS_RAW && isSensorOn) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF101914),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B3824)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (gnssState.hasHardwareFix) "● LIVE SATELLITE FIX" else "⚡ HIGH-PRECISION GNSS RAW",
                                color = Color(0xFF00E676),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "SATS: ${gnssState.satellitesCount}",
                                color = Color(0xFF80CBC4),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "GPS:${gnssState.gpsCount}  GAL:${gnssState.galileoCount}  GLO:${gnssState.glonassCount}  BEI:${gnssState.beidouCount}",
                                color = Color(0xFFBBBBBB),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "ADR: ${gnssState.carrierPhaseLockedCount} LOCKED",
                                color = Color(0xFF81C784),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "CLK DRIFT: +${String.format(Locale.US, "%.2f", gnssState.clockDriftNsPerSec)} ns/s",
                                color = Color(0xFFFFD54F),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "C/N₀: ${String.format(Locale.US, "%.1f", gnssState.avgCn0DbHz)} dB-Hz",
                                color = Color(0xFF80DEEA),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            } else {
                // IMU Subtitle or Paused Subtitle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Sensors,
                            contentDescription = null,
                            tint = Color(0xFF888888),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (isSensorOn) activeSensorName else "Manual Custom Mode (Paused)",
                            color = Color(0xFF888888),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Text(
                        text = if (isSensorOn) "Live • Δt 1.0s" else "Editable Fields",
                        color = if (isSensorOn) Color(0xFF00E676).copy(alpha = 0.8f) else Color(0xFFFFB74D),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            HorizontalDivider(color = Color(0xFF1E1E1E), thickness = 1.dp)

            // Vector 1: Position Vector r = (x, y, z)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = if (telemetrySource == TelemetrySource.GNSS_RAW) {
                        "POSITION DISPLACEMENT  r = (x, y, z)  [CARRIER PHASE / M]"
                    } else {
                        "POSITION VECTOR  r = (x, y, z)  [METERS]"
                    },
                    color = Color(0xFF888888),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isSensorOn) {
                        SensorReadoutBox(label = "X", value = telemetry.x, unit = "m", modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Y", value = telemetry.y, unit = "m", modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Z", value = telemetry.z, unit = "m", modifier = Modifier.weight(1f))
                    } else {
                        EditableSensorField(label = "X (m)", value = telemetry.x, onValueChange = { onInputChange("x", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Y (m)", value = telemetry.y, onValueChange = { onInputChange("y", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Z (m)", value = telemetry.z, onValueChange = { onInputChange("z", it) }, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Vector 2: Velocity Vector v = (vx, vy, vz)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = if (telemetrySource == TelemetrySource.GNSS_RAW) {
                        "DOPPLER VELOCITY  v = (vx, vy, vz)  [RAW DOPPLER / M/S]"
                    } else {
                        "VELOCITY VECTOR  v = (vx, vy, vz)  [M/S]"
                    },
                    color = Color(0xFF888888),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isSensorOn) {
                        SensorReadoutBox(label = "Vx", value = telemetry.vx, unit = "m/s", modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Vy", value = telemetry.vy, unit = "m/s", modifier = Modifier.weight(1f))
                        SensorReadoutBox(label = "Vz", value = telemetry.vz, unit = "m/s", modifier = Modifier.weight(1f))
                    } else {
                        EditableSensorField(label = "Vx (m/s)", value = telemetry.vx, onValueChange = { onInputChange("vx", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Vy (m/s)", value = telemetry.vy, onValueChange = { onInputChange("vy", it) }, modifier = Modifier.weight(1f))
                        EditableSensorField(label = "Vz (m/s)", value = telemetry.vz, onValueChange = { onInputChange("vz", it) }, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Parameter 7: Time Delta Step Δt
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "SAMPLING INTERVAL  Δt",
                    color = Color(0xFF888888),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                )
                if (isSensorOn) {
                    SensorReadoutBox(label = "Δt", value = telemetry.dt, unit = "seconds", modifier = Modifier.fillMaxWidth())
                } else {
                    EditableSensorField(label = "Δt (seconds)", value = telemetry.dt, onValueChange = { onInputChange("dt", it) }, modifier = Modifier.fillMaxWidth())
                }
            }

            // Action Footer: Zero Origin when ON, RUN & Clear when OFF
            if (isSensorOn) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF181818),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C2C)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onZeroOrigin() }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 9.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFCCCCCC), modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Zero Origin", color = Color(0xFFCCCCCC), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onClearInputs,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF888888)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Clear", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onRunCustom,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E676),
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.weight(2f)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("RUN", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SensorReadoutBox(
    label: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF131313),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222222)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = label,
                fontSize = 9.sp,
                color = Color(0xFF666666),
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(Modifier.height(1.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value.ifBlank { "0.000" },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1
                )
                Spacer(Modifier.width(3.dp))
                Text(
                    text = unit,
                    fontSize = 8.sp,
                    color = Color(0xFF777777),
                    fontWeight = FontWeight.Normal,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 1.dp)
                )
            }
        }
    }
}

@Composable
fun EditableSensorField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            fontSize = 9.sp,
            color = Color(0xFF888888),
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 2.dp, start = 2.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = { onValueChange(it) },
            singleLine = true,
            placeholder = { Text("0.0", color = Color(0xFF444444), fontSize = 12.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            textStyle = TextStyle(
                color = Color.White,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Start
            ),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF141414),
                unfocusedContainerColor = Color(0xFF141414),
                focusedBorderColor = Color(0xFF00E676),
                unfocusedBorderColor = Color(0xFF333333),
                cursorColor = Color(0xFF00E676)
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
```

---

## 2. QdimDriftGraphCard
This is the "Digital Wellbeing" segmented pillar chart. It draws the visual graphs using standard Compose `Canvas`. 

```kotlin
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// Note: You need to define `GraphDataPoint` data class in your app with fields:
// `instantDrift`, `accumulatedDrift`, `timeSeconds`

@Composable
fun QdimDriftGraphCard(
    graphPoints: List<GraphDataPoint>,
    isEngineRunning: Boolean,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableStateOf(-1) }
    val activeIndex = if (selectedIndex in graphPoints.indices) selectedIndex else (graphPoints.size - 1)
    val activePoint = graphPoints.getOrNull(activeIndex) ?: graphPoints.lastOrNull()
    val activeInstantDrift = activePoint?.instantDrift ?: 0.0
    val activeTime = activePoint?.timeSeconds ?: 0f

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF080808)),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF1E1E1E), RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {

            // Minimal Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    val displayValue = if (selectedIndex != -1 && activePoint != null) activeInstantDrift else (graphPoints.lastOrNull()?.instantDrift ?: 0.0)
                    Text(
                        text = String.format(Locale.US, "%.6f", displayValue),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = (-0.5).sp
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (selectedIndex != -1 && activePoint != null) "s [T+${activeTime.toInt()}s]" else "s [LIVE]",
                        fontSize = 12.sp,
                        color = Color(0xFF777777),
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 1.dp)
                    )
                }

                if (isEngineRunning) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E676))
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Canvas Graph area
            val visiblePoints = graphPoints.takeLast(22)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF000000))
                    .border(1.dp, Color(0xFF181818), RoundedCornerShape(12.dp))
                    .pointerInput(visiblePoints) {
                        detectTapGestures { offset ->
                            val slotWidth = size.width / visiblePoints.size.coerceAtLeast(1).toFloat()
                            val clickedIndex = (offset.x / slotWidth).toInt().coerceIn(0, visiblePoints.size - 1)
                            val globalIndex = graphPoints.size - visiblePoints.size + clickedIndex
                            selectedIndex = if (selectedIndex == globalIndex) -1 else globalIndex
                        }
                    }
                    .pointerInput(visiblePoints) {
                        detectDragGestures { change, _ ->
                            val slotWidth = size.width / visiblePoints.size.coerceAtLeast(1).toFloat()
                            val draggedIndex = (change.position.x / slotWidth).toInt().coerceIn(0, visiblePoints.size - 1)
                            selectedIndex = graphPoints.size - visiblePoints.size + draggedIndex
                        }
                    }
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 10.dp, vertical = 10.dp)
                ) {
                    val w = size.width
                    val h = size.height

                    if (visiblePoints.isEmpty()) {
                        drawCircle(Color.White.copy(alpha = 0.1f), radius = 12f, center = Offset(w / 2f, h / 2f))
                        return@Canvas
                    }

                    val minInstant = visiblePoints.minOf { it.instantDrift }
                    val maxInstant = visiblePoints.maxOf { it.instantDrift }
                    val rangeSpan = (maxInstant - minInstant).coerceAtLeast(0.000001)
                    val baseMin = minInstant - rangeSpan * 0.15
                    val baseMax = maxInstant + rangeSpan * 0.15

                    val count = visiblePoints.size
                    val totalSpacing = (count - 1) * 5f
                    val barWidth = ((w - totalSpacing) / count).coerceIn(6f, 26f)
                    val actualSpacing = if (count > 1) (w - barWidth * count) / (count - 1) else 0f

                    val gridLevels = 2
                    for (i in 1..gridLevels) {
                        val frac = i.toFloat() / (gridLevels + 1)
                        val y = h * (1f - frac)
                        drawLine(
                            color = Color(0xFF121212),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(3f, 6f), 0f)
                        )
                    }

                    visiblePoints.forEachIndexed { i, pt ->
                        val globalIdx = graphPoints.size - visiblePoints.size + i
                        val isSelected = (globalIdx == activeIndex)
                        val isLatest = (i == visiblePoints.size - 1)

                        val x = i * (barWidth + actualSpacing)
                        val heightFraction = (((pt.instantDrift - baseMin) / (baseMax - baseMin)).toFloat()).coerceIn(0.12f, 0.94f)
                        val barHeight = h * heightFraction
                        val y = h - barHeight

                        val barRadius = CornerRadius(barWidth / 2f, barWidth / 2f)

                        val barBrush = when {
                            isSelected -> Brush.verticalGradient(
                                colors = listOf(Color(0xFFFFFFFF), Color(0xFFCCCCCC), Color(0xFF444444)),
                                startY = y,
                                endY = h
                            )
                            isLatest -> Brush.verticalGradient(
                                colors = listOf(Color(0xFF00E676), Color(0xFF00B0FF), Color(0xFF1A1A1A)),
                                startY = y,
                                endY = h
                            )
                            else -> Brush.verticalGradient(
                                colors = listOf(Color(0xFF555555), Color(0xFF262626), Color(0xFF101010)),
                                startY = y,
                                endY = h
                            )
                        }

                        drawRoundRect(
                            color = Color(0xFF090909),
                            topLeft = Offset(x, 0f),
                            size = Size(barWidth, h),
                            cornerRadius = barRadius
                        )

                        drawRoundRect(
                            brush = barBrush,
                            topLeft = Offset(x, y),
                            size = Size(barWidth, barHeight),
                            cornerRadius = barRadius
                        )

                        if (isSelected) {
                            drawRoundRect(
                                color = Color.White.copy(alpha = 0.8f),
                                topLeft = Offset(x - 1f, y - 1f),
                                size = Size(barWidth + 2f, barHeight + 2f),
                                cornerRadius = barRadius,
                                style = Stroke(width = 1.2f)
                            )
                        }

                        if (isLatest && isEngineRunning) {
                            val capCenter = Offset(x + barWidth / 2f, y)
                            drawCircle(
                                color = Color(0xFF00E676),
                                radius = (barWidth * 0.45f).coerceAtLeast(3f),
                                center = capCenter
                            )
                        }
                    }
                }
            }
        }
    }
}
```
